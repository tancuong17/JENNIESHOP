function LinkProduct(id) {
    window.location.href = "http://localhost/shop/manage/detailproduct/" + id;
}