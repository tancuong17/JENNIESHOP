<?php

namespace App\Http\Controllers;

use App\Models\VoucherOrder;
use Illuminate\Http\Request;

class VoucherOrderController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\VoucherOrder  $voucherOrder
     * @return \Illuminate\Http\Response
     */
    public function show(VoucherOrder $voucherOrder)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\VoucherOrder  $voucherOrder
     * @return \Illuminate\Http\Response
     */
    public function edit(VoucherOrder $voucherOrder)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\VoucherOrder  $voucherOrder
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, VoucherOrder $voucherOrder)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\VoucherOrder  $voucherOrder
     * @return \Illuminate\Http\Response
     */
    public function destroy(VoucherOrder $voucherOrder)
    {
        //
    }
}
