<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo e($product['name']); ?></title>
    <link rel="shortcut icon" href="<?php echo e(URL::asset('storage/app/images/logo.jpg')); ?>">
    <link href="https://fonts.googleapis.com/css2?family=Space+Grotesk" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.css" />
    <link rel="stylesheet" href="<?php echo e(URL::asset('resources/css/store/header.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(URL::asset('resources/css/store/footer.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(URL::asset('resources/css/store/index.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(URL::asset('resources/css/store/product.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(URL::asset('resources/css/store/responsive.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(URL::asset('resources/css/store/menu_mobile.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(URL::asset('resources/css/store/usermenu.css')); ?>">
</head>
<body>
    <?php echo $__env->make('store.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('store.menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('store.usermenu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div id="main_product_page">
        <ul class="navigation">
            <li>Trang chủ</li>
            <li>Áo khoác</li>
            <li>Áo khoác UNISEX</li>
            <li>Áo Khoác Dù Unisex</li>
        </ul>
        <div id="product_info_container">
            <div id="image_product_container">
                <div style="--swiper-navigation-color: #fff; --swiper-pagination-color: #fff" class="swiper mySwiper2">
                    <div class="swiper-wrapper">
                        <?php $__currentLoopData = $images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="swiper-slide" data-src="<?php echo e($image['url']); ?>">
                                <img src="http://localhost/shop/storage/app/<?php echo e($image['url']); ?>" />
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php $__currentLoopData = $colors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $color): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="swiper-slide" data-src="<?php echo e($color['url']); ?>">
                                <img src="http://localhost/shop/storage/app/<?php echo e($color['url']); ?>"/>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                    <div class="swiper-button-next"></div>
                    <div class="swiper-button-prev"></div>
                </div>
                <div thumbsSlider="" class="swiper mySwiper">
                    <div class="swiper-wrapper">
                        <?php $__currentLoopData = $images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="swiper-slide">
                                <img src="http://localhost/shop/storage/app/<?php echo e($image['url']); ?>" />
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php $__currentLoopData = $colors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $color): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="swiper-slide" data-src="<?php echo e($color['url']); ?>">
                                <img src="http://localhost/shop/storage/app/<?php echo e($color['url']); ?>"/>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>
            <div id="product_info_right_container">
                <h1><?php echo e($product['name']); ?></h1>
                <div id="sku_container">
                    <p>SKU: <?php echo e($product['sku_code']); ?></p>
                    <p>Còn hàng</p>
                </div>
                <div id="price_info_product_container">
                    <div id="price_info_product">
                        <?php $__currentLoopData = $prices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $price): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($price['type_price'] == 0 && Carbon\Carbon::parse($price['created_at']) <= Carbon\Carbon::today() && Carbon\Carbon::parse($price['updated_at']) >= Carbon\Carbon::today()): ?>
                                <p><?php echo e(number_format($price['price'])); ?>đ</p>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php $__currentLoopData = $prices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $price): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($price['type_price'] == 1): ?>
                                <p><?php echo e(number_format($price['price'])); ?>đ</p>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                    <?php $__currentLoopData = $prices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $price): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($price['type_price'] == 0 && Carbon\Carbon::parse($price['created_at']) <= Carbon\Carbon::today() && Carbon\Carbon::parse($price['updated_at']) >= Carbon\Carbon::today()): ?>
                            <p>Thời gian khuyến mãi: từ ngày <?php echo e(date('d-m-Y', strtotime($price['created_at']))); ?> đến ngày <?php echo e(date('d-m-Y', strtotime($price['updated_at']))); ?></p>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <div>
                    <p>Màu sắc</p>
                    <div id="color_container">
                        <?php $__currentLoopData = $colors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $color): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <img data-id=<?php echo e($color['id']); ?> <?php if($loop->index == 0): ?> class="color-choosed" <?php endif; ?> src="http://localhost/shop/storage/app/<?php echo e($color['url']); ?>" data-src="<?php echo e($color['url']); ?>" data-name="<?php echo e($color['name']); ?>"/>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
                <div>
                    <p>Kích thước</p>
                    <div id="size_container">
                        <?php $__currentLoopData = $sizes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $size): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($size['id_color'] == $colors[0]['id']): ?>
                                <p class="size size-choosed" onclick="ChooseSize(this)" data-name="<?php echo e($size['name']); ?>"><?php echo e($size['name']); ?></p>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
                <div>
                    <p>Số lượng</p>
                    <div id="quantity_container">
                        <?xml version="1.0" encoding="UTF-8"?><svg id="plus_quantity" width="24px" height="24px" stroke-width="1.5" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" color="#212504"><path d="M6 12H12M18 12H12M12 12V6M12 12V18" stroke="#212504" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"></path></svg>
                        <input type="number" id="quantity_add_to_cart" value="1">
                        <?xml version="1.0" encoding="UTF-8"?><svg id="minus_quantity" width="24px" height="24px" stroke-width="1.5" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" color="#212504"><path d="M6 12H18" stroke="#212504" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"></path></svg>
                    </div>
                </div>
                <div id="product_info_right_button_container">
                    <div>
                        <?xml version="1.0" encoding="UTF-8"?><svg width="24px" height="24px" stroke-width="1.5" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" color="#212504"><path d="M8 14L16 14" stroke="#212504" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"></path><path d="M8 10L10 10" stroke="#212504" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"></path><path d="M8 18L12 18" stroke="#212504" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"></path><path d="M10 3H6C4.89543 3 4 3.89543 4 5V20C4 21.1046 4.89543 22 6 22H18C19.1046 22 20 21.1046 20 20V5C20 3.89543 19.1046 3 18 3H14.5M10 3V1M10 3V5" stroke="#212504" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"></path></svg>
                        <p>Mua ngay</p>
                    </div>
                    <div onclick="AddToCart(<?php echo e($product['id']); ?>, '<?php echo e($product['name']); ?>', <?php echo e($prices[0]['price']); ?>)">
                        <?xml version="1.0" encoding="UTF-8"?><svg width="24px" height="24px" stroke-width="1.5" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" color="#212504"><path d="M3 6H22L19 16H6L3 6ZM3 6L2.25 3.5" stroke="#212504" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"></path><path d="M9.99219 11H11.9922M13.9922 11H11.9922M11.9922 11V9M11.9922 11V13" stroke="#212504" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"></path><path d="M11 19.5C11 20.3284 10.3284 21 9.5 21C8.67157 21 8 20.3284 8 19.5" stroke="#212504" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"></path><path d="M17 19.5C17 20.3284 16.3284 21 15.5 21C14.6716 21 14 20.3284 14 19.5" stroke="#212504" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"></path></svg>
                        <p>Thêm vào giỏ hàng</p>
                    </div>
                </div>
            </div>
        </div>
        <div id="bottom_main_product_page">
            <div id="tab_container">
                <p data-tab="0">Chi tiết</p>
                <p data-tab="1">Đánh giá</p>
            </div>
        </div>
        <div id="tab_content_container">
            <div class="tab_content">
                <?php echo $product['detail']; ?>

            </div>
            <div class="tab_content">
                <p>B</p>
            </div>
        </div>
    </div>
    <?php echo $__env->make('store.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</body>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.js"></script>
<script src="<?php echo e(URL::asset('resources/js/store/index.js')); ?>"></script>
<script src="<?php echo e(URL::asset('resources/js/store/product.js')); ?>"></script>
</html><?php /**PATH C:\xampp\htdocs\shop\resources\views/store/product.blade.php ENDPATH**/ ?>