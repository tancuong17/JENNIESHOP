<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <meta http-equiv="Cache-Control" content="no-cache, no-store, must-revalidate" />
    <meta http-equiv="Pragma" content="no-cache" />
    <meta http-equiv="Expires" content="0" />
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>" />
    <title><?php echo e($product['name']); ?></title>
    <link href="https://fonts.googleapis.com/css2?family=Space+Grotesk" rel="stylesheet">
    <link rel="shortcut icon" href="<?php echo e(URL::asset('storage/app/images/logo.jpg')); ?>">
    <link rel="stylesheet" href="<?php echo e(URL::asset('resources/css/manage/index.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(URL::asset('resources/css/manage/menu.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(URL::asset('resources/css/manage/header.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(URL::asset('resources/css/manage/addproduct.css')); ?>">
</head>
<body>
    <?php echo $__env->make('manage.menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div id="main-container">
        <?php echo $__env->make('manage.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div id="add_product_container">
            <p class="title">Ảnh sản phẩm</p>
            <div id="images_container">
                <?php $__currentLoopData = $images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="image-product-upload-file-conatainer" id="images" for="image-upload-<?php echo e($image['id']); ?>">
                        <img class="image-product-upload" src="<?php echo e(env('URL_IMAGE')); ?><?php echo e($image['url']); ?>"/>
                        <?xml version="1.0" encoding="UTF-8"?><svg class="icon-delete" onclick="DeleteImageProduct(this, <?php echo e($image['id']); ?>)" width="24px" height="24px" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" color="#000000" stroke-width="1.5"><path fill-rule="evenodd" clip-rule="evenodd" d="M12 1.25C6.06294 1.25 1.25 6.06294 1.25 12C1.25 17.9371 6.06294 22.75 12 22.75C17.9371 22.75 22.75 17.9371 22.75 12C22.75 6.06294 17.9371 1.25 12 1.25ZM9.70164 8.64124C9.40875 8.34835 8.93388 8.34835 8.64098 8.64124C8.34809 8.93414 8.34809 9.40901 8.64098 9.7019L10.9391 12L8.64098 14.2981C8.34809 14.591 8.34809 15.0659 8.64098 15.3588C8.93388 15.6517 9.40875 15.6517 9.70164 15.3588L11.9997 13.0607L14.2978 15.3588C14.5907 15.6517 15.0656 15.6517 15.3585 15.3588C15.6514 15.0659 15.6514 14.591 15.3585 14.2981L13.0604 12L15.3585 9.7019C15.6514 9.40901 15.6514 8.93414 15.3585 8.64124C15.0656 8.34835 14.5907 8.34835 14.2978 8.64124L11.9997 10.9393L9.70164 8.64124Z" fill="#000000"></path></svg>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <label class="image-product-upload-file-conatainer" id="images" for="image-upload-0">
                    <input class="image-product-upload-file" onchange="UploadImageProduct(event)" type="file" id="image-upload-0" data-number="0" accept="image/png, image/gif, image/jpeg">
                    <?xml version="1.0" encoding="UTF-8"?><svg class="add-image-icon" width="24px" height="24px" stroke-width="1.5" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" color="#000000"><path d="M13 21H3.6C3.26863 21 3 20.7314 3 20.4V3.6C3 3.26863 3.26863 3 3.6 3H20.4C20.7314 3 21 3.26863 21 3.6V13" stroke="#000000" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"></path><path d="M3 16L10 13L15.5 15.5" stroke="#000000" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"></path><path d="M16 10C14.8954 10 14 9.10457 14 8C14 6.89543 14.8954 6 16 6C17.1046 6 18 6.89543 18 8C18 9.10457 17.1046 10 16 10Z" stroke="#000000" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"></path><path d="M16 19H19M22 19H19M19 19V16M19 19V22" stroke="#000000" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"></path></svg>
                </label>
            </div>
            <div class="button-update-container">
                <button class="button-w100" onclick="UpdateImage(<?php echo e($product['id']); ?>)">Cập nhật</button>
            </div>
            <p class="title">Mã SKU</p>
            <div class="input-update-container">
                <input value="<?php echo e($product['sku_code']); ?>" type="text" class="input_info" placeholder="..." id="sku">
                <button class="button" onclick="UpdateProduct(<?php echo e($product['id']); ?>, 'sku_code', this)">Cập nhật</button>
            </div>
            <p class="title">Tên</p>
            <div class="input-update-container">
                <input value="<?php echo e($product['name']); ?>" type="text" class="input_info" placeholder="..." id="name">
                <button class="button" onclick="UpdateProduct(<?php echo e($product['id']); ?>, 'name', this)">Cập nhật</button>
            </div>
            <p class="title">Giá</p>
            <div class="input-update-container">
                <?php $__currentLoopData = $prices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $price): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($price['type_price'] == 1): ?>
                        <input onkeyup="FormatMoney(this, event)" data-value="<?php echo e($price['price']); ?>" value="<?php echo e(number_format($price['price'])); ?>" type="text" class="input_info" placeholder="..." id="price">
                    <?php endif; ?> 
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <button class="button" onclick="UpdatePrice(<?php echo e($product['id']); ?>)">Cập nhật</button>
            </div>
            <p class="title">Loại sản phẩm</p>
            <div id="type-product-container">
                <?php $__currentLoopData = $typeproducts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $typeproduct): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <p class="type-product 
                        <?php $__currentLoopData = $types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($typeproduct["id"] == $type["id_type"]): ?>type-product-choosed <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    " onclick="ChooseTypeProduct(this)" data-id="<?php echo e($typeproduct['id']); ?>"><?php echo e($typeproduct['name']); ?></p> 
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <div class="button-update-container">
                <button class="button-w100" onclick="UpdateTypeProduct(<?php echo e($product['id']); ?>)">Cập nhật</button>
            </div>
            <p class="title">Giá khuyến mãi</p>
            <?php $__currentLoopData = $prices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $price): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($price['type_price'] == 0): ?>
                    <input onkeyup="FormatMoney(this, event)" data-value="<?php echo e($price['price']); ?>" value="<?php echo e(number_format($price['price'])); ?>" type="text" class="input_info" placeholder="..." id="price-promotion">
                    <p class="title">Thời gian khuyến mãi</p>
                    <div class="input-update-container">
                        <input value="<?php echo e(date('Y-m-d', strtotime($price['created_at']))); ?>" type="date" class="input_info" placeholder="..." id="start-date-price-promotion">
                        <span>-</span>
                        <input value="<?php echo e(date('Y-m-d', strtotime($price['updated_at']))); ?>" type="date" class="input_info" placeholder="..." id="end-date-price-promotion">
                    </div>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php if(count($prices) == 1): ?>
                <input type="text" class="input_info" placeholder="..." id="price-promotion">
                <p class="title">Thời gian khuyến mãi</p>
                <div class="input-update-container">
                    <input type="date" class="input_info" placeholder="..." id="start-date-price-promotion">
                    <span>-</span>
                    <input type="date" class="input_info" placeholder="..." id="end-date-price-promotion">
                </div>
            <?php endif; ?>
            <div class="button-update-container">
                <button class="button-w100" onclick="PricePromotion(<?php echo e($product['id']); ?>)">Cập nhật</button>
            </div>
            <p class="title">Màu sắc</p>
            <div id="color_container">
                <?php $__currentLoopData = $colors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $color): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="color" data-id="<?php echo e($color['id']); ?>">
                        <label class="color_image" for="image-color-upload-<?php echo e($color['id']); ?>">
                            <input value="<?php echo e($color['name']); ?>" type="text" placeholder="Tên màu sắc..." class="input_info name-color">
                            <input onchange="UploadImageColor(event)" class="image-color-upload-file" type="file" id="image-color-upload-<?php echo e($color['id']); ?>" accept="image/png, image/gif, image/jpeg">
                            <img class="image-color-upload" src=<?php echo e(env('URL_IMAGE')); ?><?php echo e($color['url']); ?>/>
                            <button class="button-w100" onclick="UpdateColor(<?php echo e($color['id']); ?>, this)">Cập nhật</button>
                        </label>
                        <div class="color_input_container">
                            <?php $__currentLoopData = $sizes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $size): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($size['id_color'] == $color['id']): ?>
                                    <div class="color_input" data-id="<?php echo e($size['id']); ?>">
                                        <p class="title">Kích thước</p>
                                        <input value="<?php echo e($size['name']); ?>" data-value="<?php echo e($size['name']); ?>" type="text" placeholder="..." class="name_size">
                                        <p class="title">Số lượng</p>
                                        <input value="<?php echo e($size['quantity']); ?>" data-value="<?php echo e($size['quantity']); ?>" type="text" placeholder="..." class="quantity_size">
                                        <button class="button-w100" onclick="UpdateSize(this, <?php echo e($size['id']); ?>)">Cập nhật</button>
                                        <?xml version="1.0" encoding="UTF-8"?><svg class="icon-delete" onclick="DeleteSizeProduct(this, <?php echo e($size['id']); ?>)" width="24px" height="24px" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" color="#000000" stroke-width="1.5"><path fill-rule="evenodd" clip-rule="evenodd" d="M12 1.25C6.06294 1.25 1.25 6.06294 1.25 12C1.25 17.9371 6.06294 22.75 12 22.75C17.9371 22.75 22.75 17.9371 22.75 12C22.75 6.06294 17.9371 1.25 12 1.25ZM9.70164 8.64124C9.40875 8.34835 8.93388 8.34835 8.64098 8.64124C8.34809 8.93414 8.34809 9.40901 8.64098 9.7019L10.9391 12L8.64098 14.2981C8.34809 14.591 8.34809 15.0659 8.64098 15.3588C8.93388 15.6517 9.40875 15.6517 9.70164 15.3588L11.9997 13.0607L14.2978 15.3588C14.5907 15.6517 15.0656 15.6517 15.3585 15.3588C15.6514 15.0659 15.6514 14.591 15.3585 14.2981L13.0604 12L15.3585 9.7019C15.6514 9.40901 15.6514 8.93414 15.3585 8.64124C15.0656 8.34835 14.5907 8.34835 14.2978 8.64124L11.9997 10.9393L9.70164 8.64124Z" fill="#000000"></path></svg>
                                    </div>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <div id="add_color_input" onclick="AddColorInputUpdate(this, <?php echo e($product['id']); ?>, <?php echo e($color['id']); ?>)">
                                <?xml version="1.0" encoding="UTF-8"?><svg width="36px" height="36px" stroke-width="1.5" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" color="#000000"><path d="M6 12H12M18 12H12M12 12V6M12 12V18" stroke="#000000" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"></path></svg>
                            </div>
                        </div>
                        <?xml version="1.0" encoding="UTF-8"?><svg class="icon-delete color-delete-button" onclick="DeleteColorProduct(this, <?php echo e($color['id']); ?>)" width="24px" height="24px" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" color="#000000" stroke-width="1.5"><path fill-rule="evenodd" clip-rule="evenodd" d="M12 1.25C6.06294 1.25 1.25 6.06294 1.25 12C1.25 17.9371 6.06294 22.75 12 22.75C17.9371 22.75 22.75 17.9371 22.75 12C22.75 6.06294 17.9371 1.25 12 1.25ZM9.70164 8.64124C9.40875 8.34835 8.93388 8.34835 8.64098 8.64124C8.34809 8.93414 8.34809 9.40901 8.64098 9.7019L10.9391 12L8.64098 14.2981C8.34809 14.591 8.34809 15.0659 8.64098 15.3588C8.93388 15.6517 9.40875 15.6517 9.70164 15.3588L11.9997 13.0607L14.2978 15.3588C14.5907 15.6517 15.0656 15.6517 15.3585 15.3588C15.6514 15.0659 15.6514 14.591 15.3585 14.2981L13.0604 12L15.3585 9.7019C15.6514 9.40901 15.6514 8.93414 15.3585 8.64124C15.0656 8.34835 14.5907 8.34835 14.2978 8.64124L11.9997 10.9393L9.70164 8.64124Z" fill="#000000"></path></svg>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <div id="add_color" onclick="AddColorUpdate(<?php echo e($product['id']); ?>)">
                    <?xml version="1.0" encoding="UTF-8"?><svg width="36px" height="36px" stroke-width="1.5" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" color="#000000"><path d="M6 12H12M18 12H12M12 12V6M12 12V18" stroke="#000000" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"></path></svg>
                </div>
            </div>
            <div class="detail-update-container">
                <p class="title">Chi tiết</p>
                <button class="button" onclick="UpdateDetailProduct(<?php echo e($product['id']); ?>)">Cập nhật</button>
            </div>
            <textarea id="detail" style="height: 500px">
                <?php echo $product['detail']; ?>

            </textarea>
            <div class="button-container">
                <button id="remove_product_btn" onclick="DeleteProduct(<?php echo e($product['id']); ?>)">Xoá sản phẩm</button>
            </div>
        </div>
    </div>
</body>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
<script src="<?php echo e(URL::asset('public/assets/vendor/ckeditor4/ckeditor.js')); ?>"></script>
<script src="<?php echo e(URL::asset('resources/js/manage/menu.js')); ?>"></script>
<script src="<?php echo e(URL::asset('resources/js/manage/detailproduct.js')); ?>"></script>
<script src="<?php echo e(URL::asset('resources/js/manage/index.js')); ?>"></script>
<script>
    CKEDITOR.config.allowedContent = true;
</script>
</html><?php /**PATH C:\xampp\htdocs\shop\resources\views/manage/detailproduct.blade.php ENDPATH**/ ?>