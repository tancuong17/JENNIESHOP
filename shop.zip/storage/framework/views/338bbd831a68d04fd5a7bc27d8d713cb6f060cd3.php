<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo e($typeProduct[0]['name']); ?></title>
    <link rel="shortcut icon" href="<?php echo e(URL::asset('storage/app/images/logo.jpg')); ?>">
    <link href="https://fonts.googleapis.com/css2?family=Space+Grotesk" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.css" />
    <link rel="stylesheet" href="<?php echo e(URL::asset('resources/css/store/header.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(URL::asset('resources/css/store/footer.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(URL::asset('resources/css/store/index.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(URL::asset('resources/css/store/responsive.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(URL::asset('resources/css/store/menu_mobile.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(URL::asset('resources/css/store/usermenu.css')); ?>">
</head>
<body>
    <?php echo $__env->make('store.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('store.menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('store.usermenu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="image-banner">
        <img src="<?php echo e(env('URL_IMAGE')); ?><?php echo e($typeProduct[0]['image']); ?>" alt="banner">
    </div>
    <div class="text_title_left">
        <ul class="navigation">
            <li>Trang chủ</li>
            <li><?php echo e($typeProduct[0]['name']); ?></li>
        </ul>
    </div>
    <?php if(count($typeProductParents) > 0): ?>
    <div id="type-product-container">
        <?php $__currentLoopData = $typeProductParents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $typeProductParent): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <a href="http://localhost/shop/loai-san-pham/<?php echo e($typeProductParent['slug']); ?>/<?php echo e($typeProductParent['id']); ?>?page=1" class="type-product"><?php echo e($typeProductParent['name']); ?></a>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    <?php endif; ?>
    <div class="product_container" <?php if(count($products) == 0): ?> style="display: block;" <?php endif; ?>>
        <?php if(count($products) == 0): ?>
            <div id="cart-empty" style="display: flex; justify-content: center; align-items: center; width: 100%; height: 26rem;">
                <img style="width: 15rem; height: 15rem;" src="https://schoolville.com/assets/img/empty-cart-illustration.gif" alt="icon">
            </div>
        <?php endif; ?>
        <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <a class="product" href="http://localhost/shop/chi-tiet-san-pham/<?php echo e($product['slug']); ?>">
                <img class="image-product" src="<?php echo e(env('URL_IMAGE')); ?><?php echo e($images[$loop->index][0]['url']); ?>" alt="product">
                <h1><?php echo e($product['name']); ?></h1>
                <div class="product_bottom">
                    <div class="price">
                        <?php $__currentLoopData = $prices[$loop->index]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $price): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($price['type_price'] == 0 && Carbon\Carbon::parse($price['created_at']) <= Carbon\Carbon::today() && Carbon\Carbon::parse($price['updated_at']) >= Carbon\Carbon::today()): ?>
                                <p><?php echo e(number_format($price['price'])); ?>đ</p>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php $__currentLoopData = $prices[$loop->index]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $price): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($price['type_price'] == 1): ?>
                                <p><?php echo e(number_format($price['price'])); ?>đ</p>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </a>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    <div class="paginator-container">
        <?php echo $typeProductDetails->links('store.paginator', ['quantity' => 2]); ?>

    </div>
    <?php echo $__env->make('store.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</body>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.js"></script>
<script src="<?php echo e(URL::asset('resources/js/store/index.js')); ?>"></script>
</html><?php /**PATH C:\xampp\htdocs\shop\resources\views/store/typeproducts.blade.php ENDPATH**/ ?>