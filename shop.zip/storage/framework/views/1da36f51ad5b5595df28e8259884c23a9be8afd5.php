<div id="header_container">
    <ul class="navigation">
        <?php if(Request::path() == 'manage/addproduct'): ?>
            <li>Sản phẩm</li>
            <li>Thêm mới</li>
        <?php elseif(str_contains(Request::path(), 'manage/listproduct')): ?>
            <li>Sản phẩm</li>
            <li>Danh sách</li>
        <?php elseif(str_contains(Request::path(), 'manage/detailproduct')): ?>
            <li>Sản phẩm</li>
            <li>Chi tiết</li>
        <?php elseif(str_contains(Request::path(), 'manage/addtypeproduct')): ?>
            <li>Loại sản phẩm</li>
            <li>Thêm mới</li>
        <?php elseif(str_contains(Request::path(), 'manage/listtypeproduct')): ?>
            <li>Loại sản phẩm</li>
            <li>Danh sách</li>
        <?php elseif(str_contains(Request::path(), 'manage/detailtypeproduct')): ?>
            <li>Loại sản phẩm</li>
            <li>Chi tiết</li>
        <?php elseif(str_contains(Request::path(), 'manage/listorder')): ?>
            <li>Đơn hàng</li>
            <li>Danh sách</li>
        <?php elseif(str_contains(Request::path(), 'manage/detailorder')): ?>
            <li>Đơn hàng</li>
            <li>Chi tiết</li>
        <?php elseif(str_contains(Request::path(), 'manage/addnews')): ?>
            <li>Tin tức</li>
            <li>Thêm</li>
        <?php elseif(str_contains(Request::path(), 'manage/listnews')): ?>
            <li>Tin tức</li>
            <li>Danh sách</li>
        <?php elseif(str_contains(Request::path(), 'manage/detailnews')): ?>
            <li>Tin tức</li>
            <li>Chi tiết</li>
        <?php elseif(str_contains(Request::path(), 'manage/listcustomer')): ?>
            <li>Khách hàng</li>
            <li>Danh sách</li>
        <?php elseif(str_contains(Request::path(), 'manage/addvoucher')): ?>
            <li>Voucher</li>
            <li>Thêm</li>
        <?php elseif(str_contains(Request::path(), 'manage/listvoucher')): ?>
            <li>Voucher</li>
            <li>Danh sách</li>
        <?php elseif(str_contains(Request::path(), 'manage/detailvoucher')): ?>
            <li>Voucher</li>
            <li>Chi tiết</li>
        <?php endif; ?>
    </ul>
    <div id="user_container">
        <div>
            <p id="user-name" data-user="<?php if(auth()->guard()->check()): ?><?php echo e(auth()->user()->id); ?><?php endif; ?>"><?php if(auth()->guard()->check()): ?><?php echo e(auth()->user()->name); ?><?php endif; ?></p>
            <p>Nhân viên</p>
        </div>
        <img id="user_logo" src="<?php echo e(env('URL_IMAGE')); ?><?php if(auth()->guard()->check()): ?><?php echo e(auth()->user()->image); ?><?php endif; ?>" alt="image">
    </div>
</div><?php /**PATH C:\xampp\htdocs\shop\resources\views/manage/header.blade.php ENDPATH**/ ?>