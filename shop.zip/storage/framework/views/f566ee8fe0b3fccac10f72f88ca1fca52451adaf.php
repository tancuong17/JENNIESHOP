<?php if($paginator->hasPages()): ?>
    <div class="pagination-container">
        <?php $__currentLoopData = $elements; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $element): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if(is_array($element)): ?>
                <?php $__currentLoopData = $element; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $page => $url): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($page == 1 && $paginator->currentPage() > 3): ?>
                        <div class="pagination">
                            <a href="./<?php echo e($quantity); ?>/?page=1"><span>1</a>
                        </div>
                        <?php if($paginator->currentPage() != 4): ?>
                            <p>...</p>
                        <?php endif; ?>
                    <?php endif; ?>
                    <?php if($page == $paginator->currentPage()|| $paginator->currentPage() - 2 == $page || $paginator->currentPage() - 1 == $page || $paginator->currentPage() + 1 == $page || $paginator->currentPage() + 2 == $page): ?>
                        <div class="pagination <?php if($page == $paginator->currentPage()): ?> pagination-active <?php endif; ?>">
                            <a href="<?php echo e($url); ?>"><span><?php echo e($page); ?></a>
                        </div>
                    <?php endif; ?>
                    <?php if($page == $paginator->lastPage() && $paginator->currentPage() != $paginator->lastPage() && $paginator->currentPage() != $paginator->lastPage() - 1  && $paginator->currentPage() != $paginator->lastPage() - 2): ?>
                        <?php if($paginator->lastPage() - $paginator->currentPage() > 3): ?>
                            <p>...</p>
                        <?php endif; ?>
                        <div class="pagination">
                            <a href="./<?php echo e($quantity); ?>/?page=<?php echo e($paginator->lastPage()); ?>"><span><?php echo e($paginator->lastPage()); ?></a>
                        </div>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
<?php endif; ?><?php /**PATH C:\xampp\htdocs\shop\resources\views/store/paginator.blade.php ENDPATH**/ ?>