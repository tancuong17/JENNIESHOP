<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Chi tiết đơn hàng</title>
    <link href="https://fonts.googleapis.com/css2?family=Space+Grotesk" rel="stylesheet">
    <link rel="shortcut icon" href="<?php echo e(URL::asset('storage/app/images/logo.jpg')); ?>">
    <link rel="stylesheet" href="<?php echo e(URL::asset('resources/css/manage/index.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(URL::asset('resources/css/manage/menu.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(URL::asset('resources/css/manage/header.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(URL::asset('resources/css/manage/order.css')); ?>">
</head>
<body>
    <?php echo $__env->make('manage.menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div id="main-container">
        <?php echo $__env->make('manage.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div id="order_container">
            <p class="title">Khách hàng</p>
            <input disabled type="text" placeholder="..." value="<?php echo e($order[0]['customer']); ?>" class="input_info" id="name">
            <p class="title">Số điện thoại</p>
            <input disabled type="text" placeholder="..." value="<?php echo e($order[0]['phonenumber']); ?>" class="input_info" id="name">
            <p class="title">Email</p>
            <input disabled type="text" placeholder="..." value="<?php echo e($order[0]['email']); ?>" class="input_info" id="name">
            <p class="title">Địa chỉ giao hàng</p>
            <input disabled type="text" placeholder="..." value="<?php echo e($order[0]['address']); ?>" class="input_info" id="name">
            <p class="title">Ghi chú</p>
            <textarea disabled name="" id="detail" cols="30" class="input_info" style="resize: none" rows="10" placeholder="..."><?php echo e($order[0]['note']); ?></textarea>
            <p class="title">Danh sách sản phẩm</p>
            <div style="display: flex; flex-direction: column; gap: 0.5rem">
                <?php $__currentLoopData = $orderdetail; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div style="height: 5rem; background: whitesmoke; display: flex; justify-content: space-between; align-items: center; padding: 0 0.5rem">
                        <div style="display: flex; justify-content: center; flex-direction: column;">
                            <p><?php echo e($product["name"]); ?> - <?php echo e($product["color"]); ?> - <?php echo e($product["size"]); ?></p>
                            <div style="display: flex; align-items: center; gap: 0.5rem;">
                                <p><?php echo e(number_format($product["price"])); ?>đ</p>
                            </div>
                        </div>
                        <div style=" display: flex; gap: 1rem; margin-top: 0.5rem; align-items: center;">
                            <p style="font-size: 1.5rem"><?php echo e($product["quantity"]); ?></p>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <div style="display: flex; justify-content: space-between; align-items: center">
                <p class="title">Tổng tiền: <?php echo e(number_format($order[0]['totalamount'])); ?>đ</p>
                <p class="title">Trạng thái: 
                    <?php if($order[0]['status'] == 0): ?>
                        Chưa giao hàng
                    <?php elseif($order[0]['status'] == 1): ?>
                        Đang giao hàng
                    <?php elseif($order[0]['status'] == 2): ?>
                        Đã giao hàng
                    <?php elseif($order[0]['status'] == 3): ?>
                        Đã huỷ
                    <?php endif; ?>
                </p>
            </div>
            <?php if($order[0]['status'] == 0): ?>
                <div class="button-container">
                    <button class="button-w100" onclick="UpdateOrder(<?php echo e($product['id']); ?>, 1)">Đang giao hàng</button>
                </div>
            <?php endif; ?>
            <?php if($order[0]['status'] == 1): ?>
                <div class="button-container">
                    <button class="button-w100" onclick="UpdateOrder(<?php echo e($product['id']); ?>, 2)">Đã giao hàng</button>
                </div>
            <?php endif; ?>
            <?php if($order[0]['status'] == 0 || $order[0]['status'] == 1): ?>
                <div class="button-container">
                    <button class="button-w100" onclick="UpdateOrder(<?php echo e($product['id']); ?>, 3)" style="background-color: rgb(175, 13, 13); border: 1px solid rgb(175, 13, 13)" id="remove_product_btn">Huỷ đơn hàng</button>
                </div>
            <?php endif; ?>
        </div>
    </div>
</body>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
<script src="<?php echo e(URL::asset('public/assets/vendor/ckeditor4/ckeditor.js')); ?>"></script>
<script src="<?php echo e(URL::asset('resources/js/manage/menu.js')); ?>"></script>
<script src="<?php echo e(URL::asset('resources/js/manage/index.js')); ?>"></script>
<script src="<?php echo e(URL::asset('resources/js/manage/order.js')); ?>"></script>
</html><?php /**PATH C:\xampp\htdocs\shop\resources\views/manage/detailorder.blade.php ENDPATH**/ ?>