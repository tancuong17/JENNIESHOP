<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <meta http-equiv="Cache-Control" content="no-cache, no-store, must-revalidate" />
    <meta http-equiv="Pragma" content="no-cache" />
    <meta http-equiv="Expires" content="0" />
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>" />
    <title>Chi tiết tin tức</title>
    <link href="https://fonts.googleapis.com/css2?family=Space+Grotesk" rel="stylesheet">
    <link rel="shortcut icon" href="<?php echo e(URL::asset('storage/app/images/logo.jpg')); ?>">
    <link rel="stylesheet" href="<?php echo e(URL::asset('resources/css/manage/index.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(URL::asset('resources/css/manage/menu.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(URL::asset('resources/css/manage/header.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(URL::asset('resources/css/manage/news.css')); ?>">
</head>
<body>
    <?php echo $__env->make('manage.menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div id="main-container">
        <?php echo $__env->make('manage.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div id="add_news_container">
            <p class="title">Chọn làm Banner</p>
            <select class="input_info" id="isBanner">
                <option value="0" <?php if($news[0]['banner'] == 0): ?> selected <?php endif; ?>>Không</option>
                <option value="1" <?php if($news[0]['banner'] == 1): ?> selected <?php endif; ?>>Có</option>
            </select>
            <p class="title">Tiêu đề</p>
            <input type="text" class="input_info" placeholder="..." id="title" value="<?php echo e($news[0]['title']); ?>">
            <p class="title">Ảnh đại diện</p>
            <label id="image-news-container" for="image-news">
                <input onchange="UploadImage(event)" type="file" id="image-news" accept="image/png, image/gif, image/jpeg">
                <img class="image-news-upload" src="<?php echo e(env('URL_IMAGE')); ?><?php echo e($news[0]['image']); ?>"/>
            </label>
            <p class="title">Nội dung</p>
            <textarea id="content"><?php echo $news[0]['content']; ?></textarea>
            <button id="add_news_btn" onclick="UpdateNews(<?php echo e($news[0]['id']); ?>)">Cập nhật</button>
            <div class="button-container">
                <button id="remove_product_btn" onclick="DeleteNews(<?php echo e($news[0]['id']); ?>)">Xoá</button>
            </div>
        </div>
    </div>
</body>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
<script src="<?php echo e(URL::asset('public/assets/vendor/ckeditor4/ckeditor.js')); ?>"></script>
<script src="<?php echo e(URL::asset('resources/js/manage/menu.js')); ?>"></script>
<script src="<?php echo e(URL::asset('resources/js/manage/news.js')); ?>"></script>
<script src="<?php echo e(URL::asset('resources/js/manage/index.js')); ?>"></script>
</html><?php /**PATH C:\xampp\htdocs\shop\resources\views/manage/detailnews.blade.php ENDPATH**/ ?>