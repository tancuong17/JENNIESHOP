<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo e($news[0]['title']); ?></title>
    <link rel="shortcut icon" href="<?php echo e(URL::asset('storage/app/images/logo.jpg')); ?>">
    <link href="https://fonts.googleapis.com/css2?family=Space+Grotesk" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.css" />
    <link rel="stylesheet" href="<?php echo e(URL::asset('resources/css/store/header.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(URL::asset('resources/css/store/footer.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(URL::asset('resources/css/store/index.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(URL::asset('resources/css/store/news.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(URL::asset('resources/css/store/responsive.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(URL::asset('resources/css/store/menu_mobile.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(URL::asset('resources/css/store/usermenu.css')); ?>">
</head>
<body>
    <?php echo $__env->make('store.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('store.menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('store.usermenu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div style="margin: 8rem 1rem 2rem" id="main_product_page">
        <ul class="navigation">
            <li>Trang chủ</li>
            <li>Tin tức</li>
        </ul>
    </div>
    <div style="margin: 0 1rem 2rem">
        <h1><?php echo e($news[0]['title']); ?></h1>
        <p>Ngày đăng: <?php echo e($news[0]['created_at']); ?></p>
    </div>
    <div id="news-content">
        <?php echo $news[0]['content']; ?>

    </div>
    <?php echo $__env->make('store.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</body>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.js"></script>
<script src="<?php echo e(URL::asset('resources/js/store/index.js')); ?>"></script>
<script>
    $("#news-content").find("img").removeAttr("style");
</script>
</html><?php /**PATH C:\xampp\htdocs\shop\resources\views/store/news.blade.php ENDPATH**/ ?>