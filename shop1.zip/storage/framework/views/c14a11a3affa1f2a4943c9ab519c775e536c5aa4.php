<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tin tức</title>
    <link rel="shortcut icon" href="<?php echo e(URL::asset('storage/app/images/logo.jpg')); ?>">
    <link href="https://fonts.googleapis.com/css2?family=Space+Grotesk" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.css" />
    <link rel="stylesheet" href="<?php echo e(URL::asset('resources/css/store/header.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(URL::asset('resources/css/store/footer.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(URL::asset('resources/css/store/index.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(URL::asset('resources/css/store/product.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(URL::asset('resources/css/store/responsive.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(URL::asset('resources/css/store/menu_mobile.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(URL::asset('resources/css/store/usermenu.css')); ?>">
</head>
<body>
    <?php echo $__env->make('store.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('store.menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('store.usermenu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <ul class="navigation" style="margin: 8rem 0 2rem 4rem">
        <li>Trang chủ</li>
        <li>Tin tức</li>
    </ul>
    <div id="news_container">
        <?php $__currentLoopData = $news; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <a class="news" href="./tin-tuc/<?php echo e($data["slug"]); ?>/<?php echo e($data["id"]); ?>">
                <img src="<?php echo e(env('URL_IMAGE')); ?><?php echo e($data["image"]); ?>" alt="news">
                <div class="news_text">
                    <p class="text-responsive"><?php echo e($data["title"]); ?></p>
                </div>
            </a>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    <div class="paginator-container">
        <?php echo $news->links('store.paginator', ['quantity' => 2]); ?>

    </div>
    <?php echo $__env->make('store.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</body>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.js"></script>
<script src="<?php echo e(URL::asset('resources/js/store/index.js')); ?>"></script>
<script src="<?php echo e(URL::asset('resources/js/store/product.js')); ?>"></script>
</html><?php /**PATH C:\xampp\htdocs\shop\resources\views/store/newslist.blade.php ENDPATH**/ ?>