<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Trang chủ</title>
    <link rel="shortcut icon" href="<?php echo e(URL::asset('storage/app/images/logo.jpg')); ?>">
    <link href="https://fonts.googleapis.com/css2?family=Space+Grotesk" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.css" />
    <link rel="stylesheet" href="<?php echo e(URL::asset('resources/css/store/header.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(URL::asset('resources/css/store/footer.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(URL::asset('resources/css/store/index.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(URL::asset('resources/css/store/product.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(URL::asset('resources/css/store/responsive.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(URL::asset('resources/css/store/menu_mobile.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(URL::asset('resources/css/store/usermenu.css')); ?>">
</head>
<body>
    <?php echo $__env->make('store.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('store.menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('store.usermenu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php if(count($news) != 0): ?>
        <div class="swiper" id="banner_slider">
            <div class="swiper-wrapper">
                <?php $__currentLoopData = $news; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($data["banner"] == 1): ?>
                        <a href="./tin-tuc/<?php echo e($data["slug"]); ?>/<?php echo e($data["id"]); ?>" class="swiper-slide">
                            <img src="<?php echo e(env('URL_IMAGE')); ?><?php echo e($data->image); ?>" alt="slider">
                        </a>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <div class="swiper-scrollbar"></div>
        </div>
    <?php endif; ?>
    <div class="title_text line text_title_center" <?php if(count($news) == 0): ?> style="margin-top: 8rem" <?php endif; ?>>
        <p>BẠN ĐANG TÌM KIẾM?</p>
    </div>
    <div id="catelory_container">
        <?php $__currentLoopData = $typeproducts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $typeproduct): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <a href="./loai-san-pham/<?php echo e($typeproduct['slug']); ?>/<?php echo e($typeproduct['id']); ?>?page=1">
                <img class="catelory_image" src="<?php echo e(env('URL_IMAGE')); ?><?php echo e($typeproduct['icon']); ?>" alt="catelory">
                <p><?php echo e($typeproduct['name']); ?></p>
                <p class="text-responsive"><?php echo e($typeproduct['detail']); ?></p>
            </a>       
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    <div class="title_text text_title_left">
        <p>SẢN PHẨM MỚI</p>
    </div>
    <div class="product_container">
        <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="product">
                <a href="./chi-tiet-san-pham/<?php echo e($product['slug']); ?>">
                    <img class="image-product" src="<?php echo e(env('URL_IMAGE')); ?><?php echo e($images[$loop->index][0]['url']); ?>" alt="product">
                    <h1><?php echo e($product['name']); ?></h1>
                </a>
                <div class="product_bottom">
                    <div class="price">
                        <?php $__currentLoopData = $prices[$loop->index]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $price): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($price['type_price'] == 0 && Carbon\Carbon::parse($price['created_at']) <= Carbon\Carbon::today() && Carbon\Carbon::parse($price['updated_at']) >= Carbon\Carbon::today()): ?>
                                <p><?php echo e(number_format($price['price'])); ?>đ</p>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php $__currentLoopData = $prices[$loop->index]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $price): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($price['type_price'] == 1): ?>
                                <p><?php echo e(number_format($price['price'])); ?>đ</p>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    <?php if(count($news) != 0): ?>
        <div class="title_text text_title_left">
            <p>TIN TỨC</p>
        </div>
    <?php endif; ?>
    <div id="news_container">
        <?php $__currentLoopData = $news; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <a class="news" href="./tin-tuc/<?php echo e($data["slug"]); ?>/<?php echo e($data["id"]); ?>">
                <img src="<?php echo e(env('URL_IMAGE')); ?><?php echo e($data["image"]); ?>" alt="news">
                <div class="news_text">
                    <p class="text-responsive"><?php echo e($data["title"]); ?></p>
                </div>
            </a>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    <?php echo $__env->make('store.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</body>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.js"></script>
<script src="<?php echo e(URL::asset('resources/js/store/index.js')); ?>"></script>
<script src="<?php echo e(URL::asset('resources/js/store/product.js')); ?>"></script>
</html><?php /**PATH C:\xampp\htdocs\shop\resources\views/index.blade.php ENDPATH**/ ?>